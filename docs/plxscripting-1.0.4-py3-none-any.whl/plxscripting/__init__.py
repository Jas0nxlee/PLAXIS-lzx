# Copyright (c) Plaxis bv. All rights reserved.
from .__version__ import (
    __title__,
    __description__,
    __url__,
    __version__,
    __license__,
    __author__,
    __author_email__,
    __copyright__,
)
