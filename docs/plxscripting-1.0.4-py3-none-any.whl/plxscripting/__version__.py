# Copyright (c) Plaxis bv. All rights reserved.
__title__ = "plxscripting"
__description__ = "Python wrapper for the PLAXIS Remote Scripting server API"
__url__ = "https://www.bentley.com"
__version__ = "1.0.4"
__author__ = "Plaxis bv"
__author_email__ = "prg-pypi-deploy@bentley.com"
__license__ = "Plaxis Public License 1.0"
__copyright__ = "Copyright (c) Plaxis bv"
